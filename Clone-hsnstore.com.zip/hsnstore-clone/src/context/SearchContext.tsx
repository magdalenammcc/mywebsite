"use client";

import type React from 'react';
import { createContext, useContext, useState } from 'react';
import { useRouter } from 'next/navigation';

interface SearchContextType {
  searchTerm: string;
  setSearchTerm: React.Dispatch<React.SetStateAction<string>>;
  isSearching: boolean;
  handleSearch: (term?: string) => void;
  clearSearch: () => void;
  searchResults: any[];
}

// Create context
const SearchContext = createContext<SearchContextType | undefined>(undefined);

// Mock product data for search
const allProducts = [
  {
    id: "prod1",
    name: "EVOWHEY PROTEIN",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/584605902.webp",
    description: "Proteína whey con sabor de HSN. Whey protein concentrate.",
    price: 10.62,
    category: "proteinas",
    tags: ["sin gluten", "sin lactosa"],
    slug: "sport-series/evowhey-protein"
  },
  {
    id: "prod2",
    name: "EVOLATE 2.0 (WHEY ISOLATE CFM)",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/1827681026.webp",
    description: "Aislado de proteína de suero de leche (WPI / Whey Iso).",
    price: 17.49,
    category: "proteinas",
    tags: ["sin lactosa"],
    slug: "sport-series/evolate-2-0-whey-isolate-cfm"
  },
  {
    id: "prod8",
    name: "EVODIET 2.0",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/473826726.jpeg",
    description: "Proteina de leche y soja. Con L-carnitina L-tartrato.",
    price: 10.96,
    category: "quemadores",
    tags: ["vegetariano"],
    slug: "sport-series/evodiet-2-0"
  },
  {
    id: "rec1",
    name: "CREATINA MONOHIDRATO DE CREAPURE®",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/2599664538.jpeg",
    description: "100% Creapure® (creatina monohidrato de AlzChem).",
    price: 14.45,
    category: "creatina",
    tags: ["sin gluten", "sin lactosa", "100% puro"],
    slug: "sport-series/creatina-monohidrato-creapure"
  },
  {
    id: "prod9",
    name: "EVOBCAA 2.0 + ENERGY (BCAA + CAFEÍNA)",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/3597595621.jpeg",
    description: "BCAA 2:1:1 con Cafeína, Betaína, Electrolitos y Vitaminas.",
    price: 12.71,
    category: "aminoacidos",
    tags: ["con cafeina"],
    slug: "sport-series/evobcaa-2-0-energy-bcaa-cafeina"
  },
  {
    id: "prod10",
    name: "CARNITINA LS 3.0 (100% L-CARNITINA L-TARTRATO)",
    brand: "Raw Series",
    image: "https://ext.same-assets.com/4253827287/1442349358.jpeg",
    description: "L-Carnitina L-Tartrato 100% Pura. Suplemento vegano.",
    price: 7.96,
    category: "quemadores",
    tags: ["vegano", "100% puro"],
    slug: "raw-series/carnitina-ls-3-0-100-l-carnitina-l-tartrato"
  },
];

// Provider component
export const SearchProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const router = useRouter();

  // Handle search function
  const handleSearch = (term?: string) => {
    const query = term !== undefined ? term : searchTerm;

    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);

    // Simulate API search delay
    setTimeout(() => {
      // Search in product names, descriptions, brands, and tags
      const results = allProducts.filter(product => {
        const searchTermLower = query.toLowerCase();
        return (
          product.name.toLowerCase().includes(searchTermLower) ||
          product.description.toLowerCase().includes(searchTermLower) ||
          product.brand.toLowerCase().includes(searchTermLower) ||
          product.category.toLowerCase().includes(searchTermLower) ||
          product.tags.some(tag => tag.toLowerCase().includes(searchTermLower))
        );
      });

      setSearchResults(results);
      setIsSearching(false);

      // Navigate to search results page with the query
      router.push(`/busqueda?q=${encodeURIComponent(query)}`);
    }, 300);
  };

  // Clear search
  const clearSearch = () => {
    setSearchTerm('');
    setSearchResults([]);
  };

  const value = {
    searchTerm,
    setSearchTerm,
    isSearching,
    handleSearch,
    clearSearch,
    searchResults
  };

  return <SearchContext.Provider value={value}>{children}</SearchContext.Provider>;
};

// Hook for using the search context
export const useSearch = () => {
  const context = useContext(SearchContext);
  if (context === undefined) {
    throw new Error('useSearch must be used within a SearchProvider');
  }
  return context;
};
