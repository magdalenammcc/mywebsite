"use client";

import type React from 'react';
import Topbar from './Topbar';
import Header from './Header';
import MainNav from '../navigation/MainNav';
import Footer from './Footer';
import { Toaster } from '@/components/ui/toaster';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="flex flex-col min-h-screen">
      <Topbar />
      <Header />
      <MainNav />
      <main className="flex-grow bg-hsn-bg">
        {children}
      </main>
      <Footer />
      <Toaster />
    </div>
  );
};

export default Layout;
