import React from 'react';
import Link from 'next/link';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { HSNLogo } from '../common/icons';

const Footer = () => {
  return (
    <footer className="bg-gray-100 text-hsn-text-primary">
      <div className="hsn-container py-10">
        {/* Footer sections */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold text-lg mb-4">ATENCIÓN AL CLIENTE</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/customer-service" className="hover:text-hsn-primary">
                  Preguntas Frecuentes
                </Link>
              </li>
              <li>
                <Link href="/contacto" className="hover:text-hsn-primary">
                  Contacto
                </Link>
              </li>
              <li>
                <Link href="/opinion" className="hover:text-hsn-primary">
                  Tu opinión cuenta
                </Link>
              </li>
              <li>
                <Link href="/gastos-de-envio" className="hover:text-hsn-primary">
                  Gastos de envío
                </Link>
              </li>
              <li>
                <Link href="/devoluciones" className="hover:text-hsn-primary">
                  Devoluciones
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">TÉRMINOS LEGALES</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/aviso-legal" className="hover:text-hsn-primary">
                  Aviso Legal
                </Link>
              </li>
              <li>
                <Link href="/condiciones-venta" className="hover:text-hsn-primary">
                  Condiciones de Venta
                </Link>
              </li>
              <li>
                <Link href="/privacidad" className="hover:text-hsn-primary">
                  Política de Privacidad
                </Link>
              </li>
              <li>
                <Link href="/cookies" className="hover:text-hsn-primary">
                  Política de Cookies
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">SOBRE NOSOTROS</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/quienes-somos" className="hover:text-hsn-primary">
                  Quiénes Somos
                </Link>
              </li>
              <li>
                <Link href="/nuestras-marcas" className="hover:text-hsn-primary">
                  Nuestras Marcas
                </Link>
              </li>
              <li>
                <Link href="/blog" className="hover:text-hsn-primary">
                  Blog HSN
                </Link>
              </li>
              <li>
                <Link href="/afiliados" className="hover:text-hsn-primary">
                  Programa de Afiliados
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">NEWSLETTER</h3>
            <p className="text-sm mb-3">
              Suscríbete a nuestra newsletter y mantente al día de todas nuestras promociones y novedades.
            </p>
            <div className="flex">
              <Input
                type="email"
                placeholder="Tu email"
                className="rounded-r-none border-r-0"
              />
              <Button
                className="bg-hsn-primary hover:bg-hsn-primary/90 text-white rounded-l-none"
              >
                Enviar
              </Button>
            </div>
            <div className="mt-4 flex space-x-3">
              <Link href="https://www.facebook.com/HSNstore" target="_blank" rel="noreferrer">
                <img
                  src="https://ext.same-assets.com/874472623/4199580466.png"
                  alt="Facebook"
                  className="w-6 h-6"
                />
              </Link>
              <Link href="https://instagram.com/hsnstore" target="_blank" rel="noreferrer">
                <img
                  src="https://ext.same-assets.com/874472623/3109565500.png"
                  alt="Instagram"
                  className="w-6 h-6"
                />
              </Link>
              <Link href="https://www.youtube.com/c/HSNstore" target="_blank" rel="noreferrer">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  className="w-6 h-6 fill-current text-gray-600"
                >
                  <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z" />
                </svg>
              </Link>
              <Link href="https://twitter.com/HSNstore" target="_blank" rel="noreferrer">
                <img
                  src="https://ext.same-assets.com/874472623/9383448.svg"
                  alt="Twitter"
                  className="w-6 h-6"
                />
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-8 border-t border-gray-300">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <HSNLogo />
            </div>
            <p className="text-sm text-gray-500">
              © {new Date().getFullYear()} HSNstore.com. Todos los derechos reservados.
            </p>
          </div>

          <div className="mt-6 flex flex-wrap justify-center gap-4">
            <img
              src="https://ext.same-assets.com/4253827287/587120452.png"
              alt="Secure Trust"
              className="h-8"
            />
            <img
              src="https://ext.same-assets.com/4253827287/3487591222.png"
              alt="DMCA Protected"
              className="h-8"
            />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
