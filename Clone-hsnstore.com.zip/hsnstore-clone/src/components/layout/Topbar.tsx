import React from 'react';
import Link from 'next/link';

const Topbar = () => {
  return (
    <div className="bg-hsn-text-primary text-white text-xs py-1">
      <div className="hsn-container flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <Link
            href="/gastos-de-envio"
            className="hover:underline"
          >
            Envío gratuito a partir de 29,99*
          </Link>
          <Link
            href="/contacts"
            className="hover:underline hidden sm:inline-block"
          >
            Contacta con nosotros aquí
          </Link>
        </div>
        <div className="flex items-center space-x-2">
          <button className="hover:underline">ES - EUR</button>
          <div className="hidden sm:flex items-center space-x-2">
            <Link href="/customer/account/login/" className="hover:underline">
              Iniciar Sesión
            </Link>
            <span>|</span>
            <Link href="/customer/account/create/" className="hover:underline">
              Crear cuenta
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Topbar;
