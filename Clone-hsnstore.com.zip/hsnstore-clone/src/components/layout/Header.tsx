"use client";

import React from 'react';
import Link from 'next/link';
import { HSNLogo, CartIcon, TrustpilotIcon, MenuIcon, UserIcon } from '../common/icons';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from '@/context/AuthContext';
import { useCart } from '@/context/CartContext';

const Header = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const { itemCount } = useCart();

  return (
    <header className="bg-white border-b border-hsn-border">
      <div className="hsn-container py-3">
        <div className="flex items-center justify-between">
          {/* Mobile Menu */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Menu">
                  <MenuIcon />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <SheetHeader>
                  <SheetTitle>
                    <HSNLogo />
                  </SheetTitle>
                </SheetHeader>
                <div className="pt-6">
                  <nav className="flex flex-col space-y-4">
                    <Link href="/nutricion-deportiva" className="font-semibold text-hsn-text-primary">
                      Nutrición Deportiva
                    </Link>
                    <Link href="/salud-bienestar" className="font-semibold text-hsn-text-primary">
                      Salud y Bienestar
                    </Link>
                    <Link href="/alimentacion-saludable" className="font-semibold text-hsn-text-primary">
                      Alimentación
                    </Link>
                    <Link href="/productos" className="font-semibold text-hsn-text-primary">
                      Todos los Productos
                    </Link>
                  </nav>

                  <div className="mt-6 pt-6 border-t border-hsn-border">
                    {isAuthenticated ? (
                      <div className="space-y-4">
                        <div className="flex items-center space-x-3 mb-4">
                          {user?.avatar && (
                            <img
                              src={user.avatar}
                              alt={user.name}
                              className="w-8 h-8 rounded-full"
                            />
                          )}
                          <div>
                            <p className="font-semibold text-hsn-text-primary">{user?.name}</p>
                            <p className="text-xs text-hsn-text-secondary">{user?.email}</p>
                          </div>
                        </div>
                        <Link href="/mi-cuenta" className="block text-hsn-text-primary hover:text-hsn-primary">
                          Mi cuenta
                        </Link>
                        <Link href="/mis-pedidos" className="block text-hsn-text-primary hover:text-hsn-primary">
                          Mis pedidos
                        </Link>
                        <button
                          onClick={logout}
                          className="block text-hsn-text-primary hover:text-hsn-primary"
                        >
                          Cerrar sesión
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <Link href="/login" className="block text-hsn-text-primary hover:text-hsn-primary font-semibold">
                          Iniciar sesión
                        </Link>
                        <Link href="/registro" className="block text-hsn-text-primary hover:text-hsn-primary">
                          Crear cuenta
                        </Link>
                      </div>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Logo */}
          <Link href="/" className="flex items-center">
            <HSNLogo />
            <span className="hidden lg:inline-block ml-2 uppercase text-[10px] font-semibold text-hsn-text-secondary max-w-[150px] leading-tight">
              Nutrición deportiva y dietética natural
            </span>
          </Link>

          {/* Desktop Search */}
          <div className="hidden md:flex flex-1 max-w-xl mx-4">
            <div className="relative w-full">
              <Input
                type="search"
                placeholder="Buscar productos..."
                className="w-full border-hsn-border focus-visible:ring-hsn-primary"
              />
              <Button
                className="absolute right-0 top-0 h-full bg-hsn-primary hover:bg-hsn-primary/90 text-white"
                size="sm"
              >
                Buscar
              </Button>
            </div>
          </div>

          {/* Trustpilot, User & Cart */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            <div className="hidden sm:flex items-center">
              <Link
                href="https://es.trustpilot.com/review/hsnstore.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center"
              >
                <TrustpilotIcon />
                <div className="ml-1 text-xs">
                  <div className="font-bold">Excelente</div>
                  <div className="text-hsn-text-secondary">4.70/5.00</div>
                </div>
              </Link>
            </div>

            {/* User Account */}
            <div className="hidden md:block">
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="relative">
                      {user?.avatar ? (
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-8 h-8 rounded-full"
                        />
                      ) : (
                        <UserIcon />
                      )}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>
                      <div>
                        <p className="font-medium">{user?.name}</p>
                        <p className="text-xs text-hsn-text-secondary">{user?.email}</p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/mi-cuenta">Mi cuenta</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/mis-pedidos">Mis pedidos</Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      onClick={logout}
                      className="text-red-600 cursor-pointer"
                    >
                      Cerrar sesión
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="flex items-center">
                  <Link href="/login" className="text-sm mr-2 text-hsn-text-primary hover:text-hsn-primary">
                    Iniciar Sesión
                  </Link>
                  <span className="text-hsn-text-secondary mx-1">|</span>
                  <Link href="/registro" className="text-sm ml-2 text-hsn-text-primary hover:text-hsn-primary">
                    Registro
                  </Link>
                </div>
              )}
            </div>

            {/* Cart */}
            <div className="flex flex-col items-center">
              <Link href="/checkout" className="relative">
                <CartIcon />
                {itemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-hsn-primary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {itemCount > 99 ? '99+' : itemCount}
                  </span>
                )}
              </Link>
              <span className="text-[10px] text-hsn-text-secondary mt-1 hidden sm:block">
                {itemCount > 0
                  ? `${itemCount} ${itemCount === 1 ? 'artículo' : 'artículos'}`
                  : 'No tiene artículos'
                }
              </span>
            </div>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="mt-3 md:hidden">
          <div className="relative w-full">
            <Input
              type="search"
              placeholder="Buscar productos..."
              className="w-full border-hsn-border focus-visible:ring-hsn-primary"
            />
            <Button
              className="absolute right-0 top-0 h-full bg-hsn-primary hover:bg-hsn-primary/90 text-white"
              size="sm"
            >
              Buscar
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
