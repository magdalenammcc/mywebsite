import type React from 'react';
import ProductCard from '../products/ProductCard';
import CountdownTimer from '../common/CountdownTimer';

interface Product {
  id: string;
  name: string;
  brand: string;
  image: string;
  description?: string;
  price: number;
  oldPrice?: number;
  discount?: number;
  rating?: number;
  reviewCount?: number;
  inStock?: boolean;
  slug: string;
}

interface FlashSaleProps {
  title: string;
  endDate: Date;
  products: Product[];
}

const FlashSale: React.FC<FlashSaleProps> = ({
  title,
  endDate,
  products,
}) => {
  return (
    <div className="bg-white p-6 rounded shadow-sm">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h2 className="text-2xl font-bold text-hsn-text-primary">{title}</h2>
        <div className="mt-2 md:mt-0 flex items-center">
          <span className="text-sm text-hsn-text-secondary mr-2">TIEMPO LIMITADO:</span>
          <CountdownTimer targetDate={endDate} />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            id={product.id}
            name={product.name}
            brand={product.brand}
            image={product.image}
            description={product.description}
            price={product.price}
            oldPrice={product.oldPrice}
            discount={product.discount}
            rating={product.rating}
            reviewCount={product.reviewCount}
            inStock={product.inStock}
            badge="OFERTA FLASH"
            slug={product.slug}
          />
        ))}
      </div>
    </div>
  );
};

export default FlashSale;
