import type React from 'react';
import ProductCard from '../products/ProductCard';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface Product {
  id: string;
  name: string;
  brand: string;
  image: string;
  description?: string;
  price: number;
  oldPrice?: number;
  discount?: number;
  rating?: number;
  reviewCount?: number;
  inStock?: boolean;
  slug: string;
}

interface ProductsCategory {
  id: string;
  name: string;
  products: Product[];
}

interface FeaturedProductsProps {
  title: string;
  categories: ProductsCategory[];
  viewAllLink?: string;
}

const FeaturedProducts: React.FC<FeaturedProductsProps> = ({
  title,
  categories,
  viewAllLink,
}) => {
  return (
    <div className="bg-white p-6 rounded shadow-sm">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-hsn-text-primary">{title}</h2>
        {viewAllLink && (
          <Button
            asChild
            variant="outline"
            className="text-hsn-primary border-hsn-primary hover:bg-hsn-primary/5"
          >
            <a href={viewAllLink}>Ver todos</a>
          </Button>
        )}
      </div>

      {categories.length > 0 && (
        <Tabs defaultValue={categories[0].id}>
          <TabsList className="mb-4">
            {categories.map((category) => (
              <TabsTrigger
                key={category.id}
                value={category.id}
                className="data-[state=active]:bg-hsn-primary data-[state=active]:text-white"
              >
                {category.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map((category) => (
            <TabsContent key={category.id} value={category.id}>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {category.products.map((product) => (
                  <ProductCard
                    key={product.id}
                    id={product.id}
                    name={product.name}
                    brand={product.brand}
                    image={product.image}
                    description={product.description}
                    price={product.price}
                    oldPrice={product.oldPrice}
                    discount={product.discount}
                    rating={product.rating}
                    reviewCount={product.reviewCount}
                    inStock={product.inStock}
                    slug={product.slug}
                  />
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      )}
    </div>
  );
};

export default FeaturedProducts;
