import type React from 'react';
import Link from 'next/link';
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from '@/components/ui/hover-card';

const MainNav = () => {
  return (
    <div className="hidden md:block bg-white border-b border-hsn-border">
      <div className="hsn-container">
        <nav className="flex">
          <NavItem
            href="/nutricion-deportiva"
            title="Nutrición Deportiva"
            subCategories={[
              { title: 'Aminoácidos', href: '/nutricion-deportiva/aminoacidos', featured: true },
              { title: 'Anabólicos naturales', href: '/nutricion-deportiva/anabolicos-naturales' },
              { title: 'Barritas', href: '/nutricion-deportiva/barritas' },
              { title: 'Carbohidratos', href: '/nutricion-deportiva/carbohidratos' },
              { title: 'Control peso', href: '/nutricion-deportiva/controlar-peso', featured: true },
              { title: 'Creatina', href: '/nutricion-deportiva/creatina', featured: true },
              { title: 'Ganadores de peso', href: '/nutricion-deportiva/ganadores-de-peso' },
              { title: 'Geles energéticos', href: '/nutricion-deportiva/geles-energeticos' },
              { title: 'Intra-entrenamiento', href: '/nutricion-deportiva/intra-entrenamiento' },
              { title: 'Minerales', href: '/nutricion-deportiva/minerales' },
              { title: 'Multivitamínicos', href: '/nutricion-deportiva/multivitaminicos' },
              { title: 'Post-entrenamiento', href: '/nutricion-deportiva/post-entrenamiento-y-recuperacion' },
              { title: 'Pre-entrenamiento', href: '/nutricion-deportiva/pre-entrenamiento' },
              { title: 'Proteínas', href: '/nutricion-deportiva/proteinas', featured: true },
              { title: 'Vitaminas', href: '/nutricion-deportiva/vitaminas' },
            ]}
            ingredients={[
              { title: 'Amilopectina', href: '/ingredientes/amilopectina' },
              { title: 'Ácido aspártico', href: '/ingredientes/acido-aspartico' },
              { title: 'Ashwagandha', href: '/ingredientes/ashwagandha' },
              { title: 'Tribulus terrestris', href: '/ingredientes/tribulus-terrestris' },
              { title: 'Beta-Alanina', href: '/ingredientes/beta-alanina' },
              { title: 'Cafeína', href: '/ingredientes/cafeina' },
              { title: 'Magnesio', href: '/ingredientes/magnesio' },
              { title: 'Citrulina', href: '/ingredientes/citrulina' },
              { title: 'Ribosa', href: '/ingredientes/ribosa' },
              { title: 'CLA', href: '/ingredientes/cla' },
            ]}
            specialties={[
              { title: 'Sin Gluten', href: '/especialidades/sin-gluten' },
              { title: 'Sin Lactosa', href: '/especialidades/sin-lactosa' },
              { title: 'Sin Edulcorantes', href: '/especialidades/sin-edulcorantes' },
              { title: 'Apto para Veganos', href: '/especialidades/apto-para-veganos' },
              { title: 'Sin Cafeína', href: '/especialidades/sin-cafeina' },
              { title: 'Sin Soja', href: '/especialidades/sin-soja' },
              { title: 'Sin Azúcar', href: '/especialidades/sin-azucar' },
              { title: '100% Puro', href: '/especialidades/100-puro' },
              { title: 'Sin Lácteos', href: '/especialidades/sin-lacteos' },
              { title: 'Sin Conservantes', href: '/especialidades/sin-conservantes' },
              { title: 'Dieta Keto', href: '/especialidades/dieta-keto' },
            ]}
            bannerUrl="https://ext.same-assets.com/874472623/3614211944.webp"
            bannerLink="/marcas/sport-series/evoenergy-maxigel-con-cafeina"
            bannerAlt="Geles Energéticos Versión XXL"
          />

          <NavItem
            href="/salud-bienestar"
            title="Salud y Bienestar"
            subCategories={[
              { title: 'Ácidos grasos esenciales', href: '/salud-bienestar/acidos-grasos-esenciales', featured: true },
              { title: 'Alergia', href: '/salud-bienestar/anti-alergia' },
              { title: 'Antioxidantes', href: '/salud-bienestar/antioxidantes', featured: true },
              { title: 'Aparato respiratorio', href: '/salud-bienestar/salud-respiratoria' },
              { title: 'Bucodental', href: '/salud-bienestar/salud-bucodental' },
              { title: 'Circulación-corazón', href: '/salud-bienestar/circulacion-corazon' },
              { title: 'Colesterol', href: '/salud-bienestar/contra-colesterol' },
              { title: 'Control de peso', href: '/salud-bienestar/perder-peso', featured: true },
              { title: 'Cosmética', href: '/salud-bienestar/cosmetica' },
              { title: 'Digestión', href: '/salud-bienestar/digestion' },
              { title: 'Estrés y ansiedad', href: '/salud-bienestar/estres-ansiedad', featured: true },
              { title: 'Salud hepática', href: '/salud-bienestar/protectores-hepaticos', featured: true },
              { title: 'Sistema inmune', href: '/salud-bienestar/sistema-inmune' },
              { title: 'Sueño', href: '/salud-bienestar/sueno-descanso', featured: true },
            ]}
            ingredients={[
              { title: 'Cúrcuma', href: '/ingredientes/curcuma' },
              { title: 'Omega-3', href: '/ingredientes/omega-3' },
              { title: '5-HTP', href: '/ingredientes/5-htp' },
              { title: 'Carnitina', href: '/ingredientes/carnitina' },
              { title: 'Ashwagandha', href: '/ingredientes/ashwagandha' },
              { title: 'Astaxantina', href: '/ingredientes/astaxantina' },
              { title: 'Cafeína', href: '/ingredientes/cafeina' },
              { title: 'Magnesio', href: '/ingredientes/magnesio' },
              { title: 'Melatonina', href: '/ingredientes/melatonina' },
              { title: 'Glutation', href: '/ingredientes/glutation' },
            ]}
            specialties={[
              { title: '100% Natural', href: '/especialidades/100-natural' },
              { title: 'Ayurvédicos', href: '/especialidades/ayurvedicos' },
              { title: 'Sin Pescado', href: '/especialidades/sin-pescado' },
              { title: 'Apto para Vegetarianos', href: '/especialidades/apto-para-vegetarianos' },
              { title: 'Sin Gluten', href: '/especialidades/sin-gluten' },
              { title: 'Apto para Veganos', href: '/especialidades/apto-para-veganos' },
              { title: '100% Puro', href: '/especialidades/100-puro' },
            ]}
            bannerUrl="https://ext.same-assets.com/874472623/2619675343.webp"
            bannerLink="/marcas/essential-series/complete-nutrigreens-colageno"
            bannerAlt="Batido Greens con Colágeno"
          />

          <NavItem
            href="/alimentacion-saludable"
            title="Alimentación"
            subCategories={[
              { title: 'Aceites', href: '/alimentacion-saludable/aceites' },
              { title: 'Alimentos ricos en fibra', href: '/alimentacion-saludable/alimentos-ricos-en-fibra' },
              { title: 'Cafés', href: '/alimentacion-saludable/cafes' },
              { title: 'Cereales y semillas', href: '/alimentacion-saludable/cereales-y-semillas' },
              { title: 'Edulcorantes', href: '/alimentacion-saludable/edulcorantes' },
            ]}
            bannerUrl="https://ext.same-assets.com/874472623/2805832710.webp"
            bannerLink="/"
            bannerAlt="Alimentación Saludable"
          />
        </nav>
      </div>
    </div>
  );
};

interface NavItemProps {
  href: string;
  title: string;
  subCategories: { title: string; href: string; featured?: boolean }[];
  ingredients?: { title: string; href: string }[];
  specialties?: { title: string; href: string }[];
  bannerUrl?: string;
  bannerLink?: string;
  bannerAlt?: string;
}

const NavItem: React.FC<NavItemProps> = ({
  href,
  title,
  subCategories,
  ingredients,
  specialties,
  bannerUrl,
  bannerLink,
  bannerAlt
}) => {
  return (
    <HoverCard openDelay={100} closeDelay={200}>
      <HoverCardTrigger asChild>
        <Link
          href={href}
          className="relative py-3 px-4 text-hsn-text-primary hover:text-hsn-primary font-semibold transition-colors"
        >
          {title}
        </Link>
      </HoverCardTrigger>
      <HoverCardContent className="w-screen" align="start">
        <div className="hsn-container pt-2 pb-6">
          <div className="flex">
            <div className="flex-1 grid grid-cols-3 gap-6">
              <div>
                <h3 className="font-bold mb-2">Selecciona Categoría</h3>
                <ul className="space-y-1">
                  {subCategories.map((category) => (
                    <li key={category.href}>
                      <Link
                        href={category.href}
                        className={`hover:text-hsn-primary text-sm ${
                          category.featured ? 'font-bold' : ''
                        }`}
                      >
                        {category.title}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {ingredients && (
                <div>
                  <h3 className="font-bold mb-2">Por Ingredientes</h3>
                  <ul className="space-y-1">
                    {ingredients.map((ingredient) => (
                      <li key={ingredient.href}>
                        <Link
                          href={ingredient.href}
                          className="hover:text-hsn-primary text-sm"
                        >
                          {ingredient.title}
                        </Link>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-2">
                    <Link
                      href="/ingredientes"
                      className="text-xs text-hsn-primary hover:underline"
                    >
                      Ver Todos Ingredientes
                    </Link>
                  </div>
                </div>
              )}

              {specialties && (
                <div>
                  <h3 className="font-bold mb-2">Por Especialidades</h3>
                  <ul className="space-y-1">
                    {specialties.map((specialty) => (
                      <li key={specialty.href}>
                        <Link
                          href={specialty.href}
                          className="hover:text-hsn-primary text-sm"
                        >
                          {specialty.title}
                        </Link>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-2">
                    <Link
                      href="/especialidades"
                      className="text-xs text-hsn-primary hover:underline"
                    >
                      Ver todas las Especialidades
                    </Link>
                  </div>
                </div>
              )}
            </div>

            {bannerUrl && (
              <div className="ml-6 flex-shrink-0" style={{ width: '250px' }}>
                <Link href={bannerLink || '#'}>
                  <img
                    src={bannerUrl}
                    alt={bannerAlt || ''}
                    className="rounded-sm"
                  />
                </Link>
              </div>
            )}
          </div>
        </div>
      </HoverCardContent>
    </HoverCard>
  );
};

export default MainNav;
