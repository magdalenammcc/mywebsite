import type React from 'react';
import Link from 'next/link';
import { StarIcon } from '../common/icons';
import { Button } from '@/components/ui/button';

interface ProductCardProps {
  id: string;
  name: string;
  brand: string;
  image: string;
  description?: string;
  price: number;
  oldPrice?: number;
  discount?: number;
  rating?: number;
  reviewCount?: number;
  inStock?: boolean;
  badge?: string;
  slug: string;
}

const ProductCard: React.FC<ProductCardProps> = ({
  id,
  name,
  brand,
  image,
  description,
  price,
  oldPrice,
  discount,
  rating = 0,
  reviewCount = 0,
  inStock = true,
  badge,
  slug,
}) => {
  return (
    <div className="hsn-product-card flex flex-col h-full">
      {/* Badge label */}
      {badge && (
        <div className="bg-hsn-primary text-white text-xs px-2 py-1 absolute top-3 left-3">
          {badge}
        </div>
      )}

      {/* Product image */}
      <Link href={`/product/${slug}`} className="block relative pt-[100%]">
        <img
          src={image}
          alt={name}
          className="absolute top-0 left-0 w-full h-full object-contain p-4"
        />
      </Link>

      {/* Product content */}
      <div className="p-4 flex flex-col flex-grow">
        {/* Brand & Title */}
        <div className="mb-2">
          <Link href={`/marcas/${brand.toLowerCase()}`}>
            <span className="text-hsn-text-secondary text-sm block">{brand}</span>
          </Link>
          <Link href={`/product/${slug}`}>
            <h3 className="font-semibold hover:text-hsn-primary transition-colors line-clamp-2 text-sm normal-case">
              {name}
            </h3>
          </Link>
        </div>

        {/* Stars */}
        {rating > 0 && (
          <div className="mb-2 flex items-center">
            <div className="flex mr-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <StarIcon key={star} filled={star <= Math.round(rating)} />
              ))}
            </div>
            {reviewCount > 0 && (
              <span className="text-xs text-hsn-text-secondary">({reviewCount})</span>
            )}
          </div>
        )}

        {/* Description */}
        {description && (
          <p className="text-xs text-hsn-text-secondary mb-4 line-clamp-3">
            {description}
          </p>
        )}

        {/* Spacer to push price and button to bottom */}
        <div className="flex-grow" />

        {/* Price */}
        <div className="flex items-baseline mb-3">
          <span className="hsn-price text-lg">
            {price.toFixed(2).replace('.', ',')}€
          </span>

          {oldPrice && oldPrice > price && (
            <>
              <span className="hsn-old-price text-sm ml-2">
                {oldPrice.toFixed(2).replace('.', ',')}€
              </span>
              {discount && (
                <span className="hsn-discount text-xs ml-2">
                  -{discount}%
                </span>
              )}
            </>
          )}
        </div>

        {/* Plan Ahorro badge */}
        <div className="flex items-center space-x-1 mb-3">
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="text-hsn-secondary"
          >
            <path
              d="M21 11.5C21 16.75 16.75 21 11.5 21C6.25 21 2 16.75 2 11.5C2 6.25 6.25 2 11.5 2"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M22 22L20 20"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M15 8H9V14H15V8Z"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M22 2L15 9"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <span className="text-xs">
            <strong>{(price * 0.97).toFixed(2).replace('.', ',')}€</strong> CON PLAN AHORRO
          </span>
        </div>

        {/* Buy button */}
        <Button
          className={`hsn-button-primary w-full ${!inStock ? 'opacity-60' : ''}`}
          disabled={!inStock}
        >
          {inStock ? 'Lo quiero!' : 'AGOTADO'}
        </Button>
      </div>
    </div>
  );
};

export default ProductCard;
