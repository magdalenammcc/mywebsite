import type React from 'react';
import { useState, useEffect } from 'react';

interface CountdownTimerProps {
  targetDate: Date;
  onComplete?: () => void;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({
  targetDate,
  onComplete
}) => {
  const calculateTimeLeft = () => {
    const difference = +targetDate - +new Date();

    if (difference <= 0) {
      onComplete?.();
      return {
        hours: '00',
        minutes: '00',
        seconds: '00',
      };
    }

    return {
      hours: String(Math.floor((difference / (1000 * 60 * 60))) % 24).padStart(2, '0'),
      minutes: String(Math.floor((difference / 1000 / 60) % 60)).padStart(2, '0'),
      seconds: String(Math.floor((difference / 1000) % 60)).padStart(2, '0'),
    };
  };

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    const timer = setTimeout(() => {
      const newTimeLeft = calculateTimeLeft();
      setTimeLeft(newTimeLeft);
    }, 1000);

    return () => clearTimeout(timer);
  });

  return (
    <div className="flex items-center space-x-1">
      <div className="flex flex-col items-center">
        <div className="bg-hsn-text-primary text-white text-xs font-bold rounded w-8 h-8 flex items-center justify-center">
          {timeLeft.hours}
        </div>
        <span className="text-[10px] text-hsn-text-secondary">HRS</span>
      </div>
      <span className="text-hsn-text-primary font-bold">:</span>
      <div className="flex flex-col items-center">
        <div className="bg-hsn-text-primary text-white text-xs font-bold rounded w-8 h-8 flex items-center justify-center">
          {timeLeft.minutes}
        </div>
        <span className="text-[10px] text-hsn-text-secondary">MIN</span>
      </div>
      <span className="text-hsn-text-primary font-bold">:</span>
      <div className="flex flex-col items-center">
        <div className="bg-hsn-text-primary text-white text-xs font-bold rounded w-8 h-8 flex items-center justify-center">
          {timeLeft.seconds}
        </div>
        <span className="text-[10px] text-hsn-text-secondary">SEG</span>
      </div>
    </div>
  );
};

export default CountdownTimer;
