"use client";

import type React from 'react';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useAuth } from '@/context/AuthContext';

export default function LoginPage() {
  const router = useRouter();
  const { login, loading } = useAuth();

  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });

  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [loginError, setLoginError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear error for this field
    if (errors[name as keyof typeof errors]) {
      setErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }

    // Clear login error
    if (loginError) {
      setLoginError(null);
    }
  };

  const validateForm = () => {
    const newErrors: { email?: string; password?: string } = {};

    // Email validation
    if (!formData.email) {
      newErrors.email = 'El email es obligatorio';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'El email no es válido';
    }

    // Password validation
    if (!formData.password) {
      newErrors.password = 'La contraseña es obligatoria';
    } else if (formData.password.length < 6) {
      newErrors.password = 'La contraseña debe tener al menos 6 caracteres';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      const success = await login(formData.email, formData.password);

      if (success) {
        // Redirect to home page or dashboard
        router.push('/');
      } else {
        setLoginError('Email o contraseña incorrectos');
      }
    } catch (error) {
      setLoginError('Ha ocurrido un error. Por favor, inténtalo de nuevo.');
    }
  };

  return (
    <div className="hsn-container py-8">
      <div className="max-w-md mx-auto bg-white p-8 border border-hsn-border rounded-sm shadow-sm">
        <h1 className="text-2xl font-bold text-hsn-text-primary mb-6 text-center">
          Iniciar Sesión
        </h1>

        {loginError && (
          <div className="bg-red-50 border border-red-200 text-red-600 p-3 rounded-sm mb-4">
            {loginError}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="email">Email*</Label>
            <Input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              value={formData.email}
              onChange={handleChange}
              className={errors.email ? 'border-red-500' : ''}
              disabled={loading}
            />
            {errors.email && (
              <p className="text-red-500 text-xs mt-1">{errors.email}</p>
            )}
          </div>

          <div>
            <div className="flex justify-between items-center">
              <Label htmlFor="password">Contraseña*</Label>
              <Link
                href="/reset-password"
                className="text-xs text-hsn-primary hover:underline"
              >
                ¿Olvidaste tu contraseña?
              </Link>
            </div>
            <Input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              value={formData.password}
              onChange={handleChange}
              className={errors.password ? 'border-red-500' : ''}
              disabled={loading}
            />
            {errors.password && (
              <p className="text-red-500 text-xs mt-1">{errors.password}</p>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="rememberMe"
              name="rememberMe"
              checked={formData.rememberMe}
              onCheckedChange={(checked) => {
                setFormData(prev => ({
                  ...prev,
                  rememberMe: checked === true
                }));
              }}
              disabled={loading}
            />
            <Label htmlFor="rememberMe" className="text-sm">
              Recordarme
            </Label>
          </div>

          <Button
            type="submit"
            className="hsn-button-primary w-full"
            disabled={loading}
          >
            {loading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
          </Button>
        </form>

        <div className="text-center mt-6">
          <p className="text-sm text-hsn-text-secondary">
            ¿No tienes una cuenta?{' '}
            <Link href="/registro" className="text-hsn-primary hover:underline">
              Regístrate
            </Link>
          </p>
        </div>

        <div className="border-t border-hsn-border mt-6 pt-6">
          <p className="text-sm text-center text-hsn-text-secondary mb-4">
            Para una demo, puedes usar:<br />
            Email: <span className="font-mono">demo@example.com</span><br />
            Contraseña: <span className="font-mono">password123</span>
          </p>
        </div>
      </div>
    </div>
  );
}
