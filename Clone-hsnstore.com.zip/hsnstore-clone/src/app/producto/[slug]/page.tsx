"use client";

import React, { useState } from 'react';
import { StarIcon } from '@/components/common/icons';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useParams } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import ProductCard from '@/components/products/ProductCard';
import { useCart } from '@/context/CartContext';
import { useToast } from "@/components/ui/use-toast"

// Mock product data (would come from API in real app)
const productsData = [
  {
    id: "prod1",
    name: "EVOWHEY PROTEIN",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/584605902.webp",
    description: "Proteína whey con sabor de HSN. Whey protein concentrate (concentrado de proteína de suero de leche) 80%. Procedente de leche de vacas alimentadas con pasto. Disponible en más de 50 deliciosos sabores. Sin aminoácidos añadidos. Endulzada solamente con sucralosa (sin calorías adicionales). Sin azúcares añadidos. Evowhey Protein es la proteína más exitosa de HSN - Valor biológico y PDCAAs de referencia nutricional. Con análisis de contenido proteico y aminograma por laboratorio externo. Sin alérgeno de soja.",
    price: 10.62,
    oldPrice: 17.90,
    discount: 41,
    rating: 4.8,
    reviewCount: 20631,
    inStock: true,
    slug: "sport-series/evowhey-protein",
    category: "proteinas",
    tags: ["sin gluten", "sin lactosa"],
    longDescription: "<p>Evowhey Protein 2.0 es la proteína más exitosa de HSN, la nueva versión tiene un sabor más intenso y una disolución perfecta.</p><p>Se trata de una proteína de suero concentrada (WPC) con un 80% de proteínas en su composición de materia prima.</p><p>Los productos de HSN han sido formulados para cuidar los ingredientes y la calidad de sus productos.</p><p>Es una proteína concentrada, por lo que su absorción es menos rápida que un hidrolizado o un aislado, además que contiene más nutrientes en su composición, como calcio, potasio, fósforo y vitaminas del grupo B.</p>",
    nutritionInfo: {
      servingSize: "30g",
      servingsPerContainer: "33",
      nutritionFacts: [
        { name: "Energía", value: "118kcal" },
        { name: "Grasas", value: "2.4g" },
        { name: "Carbohidratos", value: "1.5g" },
        { name: "Proteínas", value: "24g" },
        { name: "Sal", value: "0.15g" }
      ]
    },
    reviews: [
      { id: 1, author: "María G.", rating: 5, comment: "¡Excelente sabor! Se disuelve muy bien y tiene muy buen valor nutricional.", date: "2023-11-15" },
      { id: 2, author: "Carlos R.", rating: 4, comment: "Buen producto, pero los sabores son un poco artificiales.", date: "2023-10-22" },
      { id: 3, author: "Ana L.", rating: 5, comment: "Llevo comprando este producto dos años y nunca me ha fallado. ¡Totalmente recomendado!", date: "2023-09-05" }
    ],
    flavors: ["Chocolate", "Vainilla", "Fresa", "Plátano", "Galleta"],
    sizes: ["1kg", "2kg", "4kg"]
  },
  {
    id: "prod2",
    name: "EVOLATE 2.0 (WHEY ISOLATE CFM)",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/1827681026.webp",
    description: "Aislado de proteína de suero de leche (WPI / Whey Iso), con sabor, de HSN.",
    price: 17.49,
    oldPrice: 26.90,
    discount: 35,
    rating: 4.7,
    reviewCount: 6755,
    inStock: false,
    slug: "sport-series/evolate-2-0-whey-isolate-cfm",
    category: "proteinas",
    tags: ["sin lactosa"],
    longDescription: "<p>Evolate 2.0 es el aislado de proteína de suero (WPI) de HSN.</p><p>Se trata de una proteína altamente purificada con más de un 90% de proteínas en la materia prima, lo que significa menos grasas y carbohidratos.</p><p>Perfecta para deportistas que buscan aumentar su masa muscular o para aquellos que necesitan controlar su peso.</p>",
    nutritionInfo: {
      servingSize: "30g",
      servingsPerContainer: "33",
      nutritionFacts: [
        { name: "Energía", value: "110kcal" },
        { name: "Grasas", value: "0.5g" },
        { name: "Carbohidratos", value: "0.8g" },
        { name: "Proteínas", value: "27g" },
        { name: "Sal", value: "0.10g" }
      ]
    },
    reviews: [
      { id: 1, author: "Miguel A.", rating: 5, comment: "La mejor proteína que he probado. Se disuelve perfectamente y el sabor es muy natural.", date: "2023-12-10" },
      { id: 2, author: "Laura S.", rating: 3, comment: "El producto es bueno, pero el precio es un poco elevado comparado con otras marcas.", date: "2023-11-03" }
    ],
    flavors: ["Chocolate", "Vainilla", "Fresa"],
    sizes: ["1kg", "2kg"]
  }
];

// Related products
const relatedProducts = [
  {
    id: "rec1",
    name: "CREATINA MONOHIDRATO DE CREAPURE®",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/2599664538.jpeg",
    description: "100% Creapure® (creatina monohidrato de AlzChem) - La creatina de referencia mundial.",
    price: 14.45,
    oldPrice: 24.90,
    discount: 42,
    rating: 4.8,
    reviewCount: 11247,
    inStock: true,
    slug: "sport-series/creatina-monohidrato-creapure"
  },
  {
    id: "prod8",
    name: "EVODIET 2.0",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/473826726.jpeg",
    description: "Proteina de leche y soja. Con L-carnitina L-tartrato. Con Capsimax y Tolerase.",
    price: 10.96,
    oldPrice: 18.90,
    discount: 42,
    rating: 4.3,
    reviewCount: 280,
    inStock: true,
    slug: "sport-series/evodiet-2-0"
  },
  {
    id: "prod9",
    name: "EVOBCAA 2.0 + ENERGY (BCAA + CAFEÍNA)",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/3597595621.jpeg",
    description: "BCAA 2:1:1 con Cafeína, Betaína, Electrolitos y Vitaminas.",
    price: 12.71,
    oldPrice: 21.90,
    discount: 42,
    rating: 4.7,
    reviewCount: 619,
    inStock: true,
    slug: "sport-series/evobcaa-2-0-energy-bcaa-cafeina"
  }
];

export default function ProductDetail() {
  const params = useParams();
  const { toast } = useToast();
  const { addItem } = useCart();
  const slug = params.slug as string;

  // Find the product by slug
  const product = productsData.find(p => p.slug.includes(slug)) || productsData[0];

  // States for product options
  const [selectedFlavor, setSelectedFlavor] = useState(product.flavors?.[0] || "");
  const [selectedSize, setSelectedSize] = useState(product.sizes?.[0] || "");
  const [quantity, setQuantity] = useState(1);

  // Price calculation with size factor
  const getSizePrice = (size: string) => {
    if (size === "1kg") return product.price;
    if (size === "2kg") return product.price * 1.8;
    if (size === "4kg") return product.price * 3.5;
    return product.price;
  }

  const currentPrice = getSizePrice(selectedSize);
  const oldPrice = product.oldPrice ? (selectedSize === "1kg" ? product.oldPrice : getSizePrice(selectedSize) / (1 - product.discount / 100)) : null;

  // Add to cart handler
  const handleAddToCart = () => {
    if (!product.inStock) return;

    addItem({
      id: product.id,
      name: product.name,
      brand: product.brand,
      image: product.image,
      price: currentPrice,
      oldPrice: oldPrice || undefined,
      discount: product.discount,
      size: selectedSize || undefined,
      flavor: selectedFlavor || undefined,
      quantity,
      slug: product.slug
    });

    toast({
      title: "Producto añadido al carrito",
      description: `${product.name} (${selectedSize}${selectedFlavor ? `, ${selectedFlavor}` : ''}) x ${quantity}`,
    });
  };

  return (
    <div className="hsn-container py-8">
      {/* Breadcrumb */}
      <div className="flex text-sm text-hsn-text-secondary mb-6">
        <Link href="/" className="hover:text-hsn-primary">Inicio</Link>
        <span className="mx-2">/</span>
        <Link href="/productos" className="hover:text-hsn-primary">Productos</Link>
        <span className="mx-2">/</span>
        <Link href={`/productos/${product.category}`} className="hover:text-hsn-primary capitalize">{product.category}</Link>
        <span className="mx-2">/</span>
        <span className="text-hsn-text-primary">{product.name}</span>
      </div>

      {/* Product Info */}
      <div className="flex flex-col lg:flex-row bg-white rounded shadow-sm overflow-hidden mb-8">
        {/* Product Image */}
        <div className="w-full lg:w-1/2 p-8 flex items-center justify-center">
          <div className="relative w-full h-[400px]">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-contain"
            />
          </div>
        </div>

        {/* Product Details */}
        <div className="w-full lg:w-1/2 p-8 border-t lg:border-t-0 lg:border-l border-hsn-border">
          {/* Brand & Title */}
          <Link href={`/marcas/${product.brand.toLowerCase().replace(' ', '-')}`}>
            <span className="text-hsn-text-secondary text-sm">{product.brand}</span>
          </Link>
          <h1 className="text-2xl font-bold text-hsn-text-primary mb-2">{product.name}</h1>

          {/* Rating */}
          <div className="flex items-center mb-4">
            <div className="flex mr-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <StarIcon key={star} filled={star <= Math.round(product.rating)} />
              ))}
            </div>
            <span className="text-sm text-hsn-text-secondary">({product.reviewCount} reseñas)</span>
          </div>

          {/* Short Description */}
          <p className="text-hsn-text-secondary mb-6">
            {product.description}
          </p>

          {/* Prices */}
          <div className="flex items-baseline mb-4">
            <span className="hsn-price text-2xl">
              {currentPrice.toFixed(2).replace('.', ',')}€
            </span>

            {oldPrice && (
              <>
                <span className="hsn-old-price text-lg ml-2">
                  {oldPrice.toFixed(2).replace('.', ',')}€
                </span>
                {product.discount && (
                  <span className="hsn-discount text-sm ml-2 bg-hsn-secondary text-white px-2 py-1 rounded">
                    -{product.discount}%
                  </span>
                )}
              </>
            )}
          </div>

          {/* Plan Ahorro */}
          <div className="flex items-center bg-gray-50 p-3 rounded mb-6">
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="text-hsn-secondary mr-2"
            >
              <path
                d="M21 11.5C21 16.75 16.75 21 11.5 21C6.25 21 2 16.75 2 11.5C2 6.25 6.25 2 11.5 2"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M22 22L20 20"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M15 8H9V14H15V8Z"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M22 2L15 9"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <div>
              <p className="text-sm font-semibold">Plan Ahorro</p>
              <p className="text-xs text-hsn-text-secondary">
                Ahorra un 3% adicional: <strong>{(currentPrice * 0.97).toFixed(2).replace('.', ',')}€</strong>
              </p>
            </div>
          </div>

          {/* Product Options */}
          {/* Flavors */}
          {product.flavors && product.flavors.length > 0 && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-hsn-text-primary mb-2">
                Sabor:
              </label>
              <div className="flex flex-wrap gap-2">
                {product.flavors.map(flavor => (
                  <button
                    key={flavor}
                    onClick={() => setSelectedFlavor(flavor)}
                    className={`px-3 py-2 text-sm border rounded-sm ${
                      selectedFlavor === flavor
                        ? 'border-hsn-primary text-hsn-primary bg-hsn-primary/5'
                        : 'border-hsn-border text-hsn-text-secondary hover:border-hsn-text-primary'
                    }`}
                  >
                    {flavor}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Sizes */}
          {product.sizes && product.sizes.length > 0 && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-hsn-text-primary mb-2">
                Tamaño:
              </label>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map(size => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`px-3 py-2 text-sm border rounded-sm ${
                      selectedSize === size
                        ? 'border-hsn-primary text-hsn-primary bg-hsn-primary/5'
                        : 'border-hsn-border text-hsn-text-secondary hover:border-hsn-text-primary'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-hsn-text-primary mb-2">
              Cantidad:
            </label>
            <div className="flex items-center">
              <button
                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                className="w-10 h-10 border border-hsn-border rounded-l-sm flex items-center justify-center text-lg"
                disabled={quantity <= 1}
              >
                -
              </button>
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(Number.parseInt(e.target.value) || 1)}
                className="w-16 h-10 border-t border-b border-hsn-border text-center"
              />
              <button
                onClick={() => setQuantity(q => q + 1)}
                className="w-10 h-10 border border-hsn-border rounded-r-sm flex items-center justify-center text-lg"
              >
                +
              </button>
            </div>
          </div>

          {/* Add to Cart */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              className="hsn-button-primary flex-1 h-12"
              disabled={!product.inStock}
              onClick={handleAddToCart}
            >
              {product.inStock ? 'AÑADIR AL CARRITO' : 'AGOTADO'}
            </Button>
            <Button
              variant="outline"
              className="border-hsn-primary text-hsn-primary hover:bg-hsn-primary/5 h-12"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="currentColor"
                className="w-6 h-6"
              >
                <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
              </svg>
            </Button>
          </div>

          {/* Tags */}
          {product.tags && product.tags.length > 0 && (
            <div className="mt-6">
              <p className="text-sm font-medium text-hsn-text-primary mb-2">Especialidades:</p>
              <div className="flex flex-wrap gap-2">
                {product.tags.map(tag => (
                  <Link
                    key={tag}
                    href={`/especialidades/${tag.replace(' ', '-')}`}
                    className="px-2 py-1 bg-gray-100 text-hsn-text-secondary text-xs rounded-sm capitalize"
                  >
                    {tag}
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Product Tabs */}
      <div className="bg-white rounded shadow-sm p-6 mb-8">
        <Tabs defaultValue="description" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger
              value="description"
              className="data-[state=active]:bg-hsn-primary data-[state=active]:text-white"
            >
              Descripción
            </TabsTrigger>
            <TabsTrigger
              value="nutrition"
              className="data-[state=active]:bg-hsn-primary data-[state=active]:text-white"
            >
              Información Nutricional
            </TabsTrigger>
            <TabsTrigger
              value="reviews"
              className="data-[state=active]:bg-hsn-primary data-[state=active]:text-white"
            >
              Reseñas ({product.reviews?.length || 0})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="description" className="p-4">
            <div dangerouslySetInnerHTML={{ __html: product.longDescription || product.description }} />
          </TabsContent>

          <TabsContent value="nutrition" className="p-4">
            {product.nutritionInfo ? (
              <div>
                <h3 className="font-bold mb-4">Información Nutricional</h3>
                <p className="mb-2">Tamaño de la porción: {product.nutritionInfo.servingSize}</p>
                <p className="mb-4">Porciones por envase: {product.nutritionInfo.servingsPerContainer}</p>

                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="p-2 text-left border border-hsn-border">Nutrientes</th>
                      <th className="p-2 text-left border border-hsn-border">Por porción</th>
                    </tr>
                  </thead>
                  <tbody>
                    {product.nutritionInfo.nutritionFacts.map((fact, index) => (
                      <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="p-2 border border-hsn-border">{fact.name}</td>
                        <td className="p-2 border border-hsn-border">{fact.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p>Información nutricional no disponible para este producto.</p>
            )}
          </TabsContent>

          <TabsContent value="reviews" className="p-4">
            {product.reviews && product.reviews.length > 0 ? (
              <div>
                <h3 className="font-bold mb-4">Opiniones de clientes</h3>
                <div className="space-y-6">
                  {product.reviews.map(review => (
                    <div key={review.id} className="border-b border-hsn-border pb-4">
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold">{review.author}</span>
                        <span className="text-sm text-hsn-text-secondary">{review.date}</span>
                      </div>
                      <div className="flex mb-2">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <StarIcon key={star} filled={star <= review.rating} />
                        ))}
                      </div>
                      <p className="text-hsn-text-secondary">{review.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <p>No hay reseñas disponibles para este producto.</p>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div className="mb-8">
        <h2 className="text-xl font-bold text-hsn-text-primary mb-6">Productos relacionados</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {relatedProducts.map(product => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              brand={product.brand}
              image={product.image}
              description={product.description}
              price={product.price}
              oldPrice={product.oldPrice}
              discount={product.discount}
              rating={product.rating}
              reviewCount={product.reviewCount}
              inStock={product.inStock}
              slug={product.slug}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
