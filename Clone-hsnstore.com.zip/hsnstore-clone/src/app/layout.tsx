import "@/app/globals.css";
import type { Metadata } from "next";
import ClientBody from "@/app/ClientBody";
import { AuthProvider } from "@/context/AuthContext";
import { CartProvider } from "@/context/CartContext";

export const metadata: Metadata = {
  title: "HSNstore - Tienda de Suplementos Deportivos y Dietética Natural",
  description: "HSNstore.com, tu tienda online de nutrición deportiva y dietética natural. Los mejores precios y envíos en 24 horas.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <AuthProvider>
        <CartProvider>
          <ClientBody>
            {children}
          </ClientBody>
        </CartProvider>
      </AuthProvider>
    </html>
  );
}
