"use client";

import type React from 'react';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useAuth } from '@/context/AuthContext';

export default function RegisterPage() {
  const router = useRouter();
  const { register, loading } = useAuth();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    acceptTerms: false,
    newsletter: false
  });

  const [errors, setErrors] = useState<{
    name?: string;
    email?: string;
    password?: string;
    confirmPassword?: string;
    acceptTerms?: string;
  }>({});

  const [registerError, setRegisterError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear error for this field
    if (errors[name as keyof typeof errors]) {
      setErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }

    // Clear register error
    if (registerError) {
      setRegisterError(null);
    }
  };

  const validateForm = () => {
    const newErrors: {
      name?: string;
      email?: string;
      password?: string;
      confirmPassword?: string;
      acceptTerms?: string;
    } = {};

    // Name validation
    if (!formData.name.trim()) {
      newErrors.name = 'El nombre es obligatorio';
    }

    // Email validation
    if (!formData.email) {
      newErrors.email = 'El email es obligatorio';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'El email no es válido';
    }

    // Password validation
    if (!formData.password) {
      newErrors.password = 'La contraseña es obligatoria';
    } else if (formData.password.length < 6) {
      newErrors.password = 'La contraseña debe tener al menos 6 caracteres';
    }

    // Confirm password validation
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Debes confirmar la contraseña';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Las contraseñas no coinciden';
    }

    // Terms validation
    if (!formData.acceptTerms) {
      newErrors.acceptTerms = 'Debes aceptar los términos y condiciones';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      const success = await register(formData.name, formData.email, formData.password);

      if (success) {
        router.push('/');
      } else {
        setRegisterError('Este email ya está registrado. Por favor, usa otro o inicia sesión.');
      }
    } catch (error) {
      setRegisterError('Ha ocurrido un error. Por favor, inténtalo de nuevo.');
    }
  };

  return (
    <div className="hsn-container py-8">
      <div className="max-w-md mx-auto bg-white p-8 border border-hsn-border rounded-sm shadow-sm">
        <h1 className="text-2xl font-bold text-hsn-text-primary mb-6 text-center">
          Crear cuenta
        </h1>

        {registerError && (
          <div className="bg-red-50 border border-red-200 text-red-600 p-3 rounded-sm mb-4">
            {registerError}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Nombre completo*</Label>
            <Input
              id="name"
              name="name"
              autoComplete="name"
              value={formData.name}
              onChange={handleChange}
              className={errors.name ? 'border-red-500' : ''}
              disabled={loading}
            />
            {errors.name && (
              <p className="text-red-500 text-xs mt-1">{errors.name}</p>
            )}
          </div>

          <div>
            <Label htmlFor="email">Email*</Label>
            <Input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              value={formData.email}
              onChange={handleChange}
              className={errors.email ? 'border-red-500' : ''}
              disabled={loading}
            />
            {errors.email && (
              <p className="text-red-500 text-xs mt-1">{errors.email}</p>
            )}
          </div>

          <div>
            <Label htmlFor="password">Contraseña*</Label>
            <Input
              id="password"
              name="password"
              type="password"
              autoComplete="new-password"
              value={formData.password}
              onChange={handleChange}
              className={errors.password ? 'border-red-500' : ''}
              disabled={loading}
            />
            {errors.password && (
              <p className="text-red-500 text-xs mt-1">{errors.password}</p>
            )}
          </div>

          <div>
            <Label htmlFor="confirmPassword">Confirmar contraseña*</Label>
            <Input
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              autoComplete="new-password"
              value={formData.confirmPassword}
              onChange={handleChange}
              className={errors.confirmPassword ? 'border-red-500' : ''}
              disabled={loading}
            />
            {errors.confirmPassword && (
              <p className="text-red-500 text-xs mt-1">{errors.confirmPassword}</p>
            )}
          </div>

          <div className="pt-4">
            <div className="flex items-start space-x-2 mb-4">
              <Checkbox
                id="acceptTerms"
                name="acceptTerms"
                checked={formData.acceptTerms}
                onCheckedChange={(checked) => {
                  setFormData(prev => ({
                    ...prev,
                    acceptTerms: checked === true
                  }));

                  if (errors.acceptTerms) {
                    setErrors(prev => ({
                      ...prev,
                      acceptTerms: undefined
                    }));
                  }
                }}
                className={errors.acceptTerms ? 'border-red-500' : ''}
                disabled={loading}
              />
              <Label htmlFor="acceptTerms" className="text-sm">
                Acepto los <Link href="/terminos" className="text-hsn-primary hover:underline">Términos y Condiciones</Link> y la <Link href="/privacidad" className="text-hsn-primary hover:underline">Política de Privacidad</Link>*
              </Label>
            </div>
            {errors.acceptTerms && (
              <p className="text-red-500 text-xs mb-4">{errors.acceptTerms}</p>
            )}

            <div className="flex items-center space-x-2">
              <Checkbox
                id="newsletter"
                name="newsletter"
                checked={formData.newsletter}
                onCheckedChange={(checked) => {
                  setFormData(prev => ({
                    ...prev,
                    newsletter: checked === true
                  }));
                }}
                disabled={loading}
              />
              <Label htmlFor="newsletter" className="text-sm">
                Suscribirme a la newsletter
              </Label>
            </div>
          </div>

          <Button
            type="submit"
            className="hsn-button-primary w-full"
            disabled={loading}
          >
            {loading ? 'Registrando...' : 'Registrarse'}
          </Button>
        </form>

        <div className="text-center mt-6">
          <p className="text-sm text-hsn-text-secondary">
            ¿Ya tienes una cuenta?{' '}
            <Link href="/login" className="text-hsn-primary hover:underline">
              Iniciar sesión
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
