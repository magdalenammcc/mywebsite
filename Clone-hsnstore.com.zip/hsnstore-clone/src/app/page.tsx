"use client";

import React from "react";
import BannerSlider from "@/components/home/BannerSlider";
import FlashSale from "@/components/home/FlashSale";
import FeaturedProducts from "@/components/home/FeaturedProducts";
import ProductCard from "@/components/products/ProductCard";

// Mock data for the page
const banners = [
  {
    id: 1,
    imageUrl: "https://ext.same-assets.com/4253827287/1989415476.webp",
    link: "/promociones/list-promo",
    alt: "Hasta 60% DTO en RawSeries",
  },
  {
    id: 2,
    imageUrl: "https://ext.same-assets.com/874472623/2619675343.webp",
    link: "/marcas/essential-series/complete-nutrigreens-colageno",
    alt: "Batido Greens con Colágeno",
  },
  {
    id: 3,
    imageUrl: "https://ext.same-assets.com/874472623/2805832710.webp",
    link: "/alimentacion-saludable",
    alt: "Alimentación Saludable",
  },
];

const flashSaleProducts = [
  {
    id: "prod1",
    name: "EVOWHEY PROTEIN",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/584605902.webp",
    description: "Proteína whey con sabor de HSN. Whey protein concentrate (concentrado de proteína de suero de leche) 80%.",
    price: 10.62,
    oldPrice: 17.90,
    discount: 41,
    rating: 4.8,
    reviewCount: 20631,
    inStock: true,
    slug: "sport-series/evowhey-protein",
  },
  {
    id: "prod2",
    name: "EVOLATE 2.0 (WHEY ISOLATE CFM)",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/1827681026.webp",
    description: "Aislado de proteína de suero de leche (WPI / Whey Iso), con sabor, de HSN.",
    price: 17.49,
    oldPrice: 26.90,
    discount: 35,
    rating: 4.7,
    reviewCount: 6755,
    inStock: false,
    slug: "sport-series/evolate-2-0-whey-isolate-cfm",
  },
  {
    id: "prod3",
    name: "EVOCASEIN 2.0 (CASEÍNA MICELAR + DIGEZYME)",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/4055366910.webp",
    description: "100% Caseína Micelar. De vacas alimentadas con pasto. Textura cremosa. Con Digezyme. Apto para vegetarianos.",
    price: 11.54,
    oldPrice: 19.90,
    discount: 42,
    rating: 4.6,
    reviewCount: 2185,
    inStock: true,
    slug: "sport-series/evocasein-2-0-caseina-micelar-digezyme",
  },
];

const featuredCategories = [
  {
    id: "cat1",
    name: "Proteínas",
    products: [
      {
        id: "prod4",
        name: "EVONATIVE CASEIN (Lacprodan Micelpure)",
        brand: "Sport Series",
        image: "https://ext.same-assets.com/4253827287/3264842839.webp",
        description: "Aislado de caseína micelar. Lacprodan MicelPure de Arla. Primera caseína nativa del mundo con un 87% de micelas en su materia prima.",
        price: 13.28,
        oldPrice: 22.90,
        discount: 42,
        rating: 4.5,
        reviewCount: 247,
        inStock: true,
        slug: "sport-series/evonative-casein-lacprodan-micelpure",
      },
      {
        id: "prod5",
        name: "EVOCLEAR HYDRO VEGAN",
        brand: "Sport Series",
        image: "https://ext.same-assets.com/4253827287/4287505174.webp",
        description: "Proteína Clear Hydro Vegan. Hidrolizado de proteína de guisante. Alta acuosidad, textura ultra-ligera.",
        price: 21.14,
        oldPrice: 39.90,
        discount: 47,
        rating: 4.3,
        reviewCount: 92,
        inStock: true,
        slug: "sport-series/evoclear-hydro-vegan",
      },
      {
        id: "prod6",
        name: "PROTEÍNA DE SOJA AISLADA 2.0",
        brand: "Essential Series",
        image: "https://ext.same-assets.com/4253827287/343202109.webp",
        description: "Proteína vegetal aislada 100% a base de soja, máxima calidad nutricional con un sabor y textura irresistibles.",
        price: 7.48,
        oldPrice: 12.90,
        discount: 42,
        rating: 4.6,
        reviewCount: 3226,
        inStock: true,
        slug: "essential-series/proteina-de-soja-aislada-2-0",
      },
      {
        id: "prod7",
        name: "EVOPRO (MEZCLA PROTEÍNAS PREMIUM) + DIGEZYME",
        brand: "Sport Series",
        image: "https://ext.same-assets.com/4253827287/845846017.webp",
        description: "Proteína secuencial. 49% WPI + 46% MPI. 65% Whey / 35% Caseína.",
        price: 12.71,
        oldPrice: 21.90,
        discount: 42,
        rating: 4.4,
        reviewCount: 439,
        inStock: true,
        slug: "sport-series/evopro-mezcla-proteinas-premium-digezyme",
      },
    ],
  },
  {
    id: "cat2",
    name: "Quemadores",
    products: [
      {
        id: "prod8",
        name: "EVODIET 2.0",
        brand: "Sport Series",
        image: "https://ext.same-assets.com/4253827287/473826726.jpeg",
        description: "Proteina de leche y soja. Con L-carnitina L-tartrato. Con Capsimax y Tolerase.",
        price: 10.96,
        oldPrice: 18.90,
        discount: 42,
        rating: 4.3,
        reviewCount: 280,
        inStock: true,
        slug: "sport-series/evodiet-2-0",
      },
      {
        id: "prod9",
        name: "EVOBCAA 2.0 + ENERGY (BCAA + CAFEÍNA)",
        brand: "Sport Series",
        image: "https://ext.same-assets.com/4253827287/3597595621.jpeg",
        description: "BCAA 2:1:1 con Cafeína, Betaína, Electrolitos y Vitaminas.",
        price: 12.71,
        oldPrice: 21.90,
        discount: 42,
        rating: 4.7,
        reviewCount: 619,
        inStock: true,
        slug: "sport-series/evobcaa-2-0-energy-bcaa-cafeina",
      },
      {
        id: "prod10",
        name: "CARNITINA LS 3.0 (100% L-CARNITINA L-TARTRATO)",
        brand: "Raw Series",
        image: "https://ext.same-assets.com/4253827287/1442349358.jpeg",
        description: "L-Carnitina L-Tartrato 100% Pura. Suplemento vegano.",
        price: 7.96,
        oldPrice: 19.90,
        discount: 60,
        rating: 4.6,
        reviewCount: 323,
        inStock: true,
        slug: "raw-series/carnitina-ls-3-0-100-l-carnitina-l-tartrato",
      },
      {
        id: "prod11",
        name: "EVOTEA (TÉ VERDE + GUARANÁ + L-CARNITINA)",
        brand: "Sport Series",
        image: "https://ext.same-assets.com/4253827287/2147654426.jpeg",
        description: "Té verde + Guaraná + Carnitina. Sin maltodextrina. Con cafeína natural.",
        price: 11.54,
        oldPrice: 19.90,
        discount: 42,
        rating: 4.5,
        reviewCount: 180,
        inStock: true,
        slug: "sport-series/evotea-te-verde-guarana-l-carnitina",
      },
    ],
  },
];

const recommendedProducts = [
  {
    id: "rec1",
    name: "CREATINA MONOHIDRATO DE CREAPURE®",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/2599664538.jpeg",
    description: "100% Creapure® (creatina monohidrato de AlzChem) - La creatina de referencia mundial.",
    price: 14.45,
    oldPrice: 24.90,
    discount: 42,
    rating: 4.8,
    reviewCount: 11247,
    inStock: true,
    slug: "sport-series/creatina-monohidrato-creapure",
  },
  {
    id: "rec2",
    name: "CICLO CARNITINA + CLA",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/3850476911.jpeg",
    description: "Carnitina + CLA. Sin estimulantes. Efecto definición.",
    price: 18.56,
    oldPrice: 32.00,
    discount: 42,
    rating: 4.6,
    reviewCount: 562,
    inStock: true,
    slug: "sport-series/ciclo-carnitina-cla",
  },
  {
    id: "rec3",
    name: "ASHWAGANDHA 500mg (WITHANIA SOMNIFERA)",
    brand: "Raw Series",
    image: "https://ext.same-assets.com/4253827287/2979023910.jpeg",
    description: "Extracto estandarizado KSM-66. Raíz de Withania somnifera. Sin excipientes.",
    price: 7.96,
    oldPrice: 19.90,
    discount: 60,
    rating: 4.7,
    reviewCount: 738,
    inStock: true,
    slug: "raw-series/ashwagandha-500mg-withania-somnifera",
  },
  {
    id: "rec4",
    name: "MAGNESIO MALATO",
    brand: "Raw Series",
    image: "https://ext.same-assets.com/4253827287/1183059626.jpeg",
    description: "Bis-glicinato y malato de magnesio, alta biodisponibilidad. Formato en polvo.",
    price: 5.96,
    oldPrice: 14.90,
    discount: 60,
    rating: 4.6,
    reviewCount: 876,
    inStock: true,
    slug: "raw-series/magnesio-malato",
  },
];

export default function Home() {
  // Create an end date for the flash sale (24 hours from now)
  const endDate = new Date();
  endDate.setHours(endDate.getHours() + 24);

  return (
    <div>
      {/* Banner Slider */}
      <BannerSlider banners={banners} />

      {/* Main content */}
      <div className="hsn-container py-8">
        <div className="space-y-8">
          {/* Flash Sale Section */}
          <section>
            <h2 className="text-center font-bold text-hsn-text-primary text-xl mb-6">
              AQUÍ O MÁS RÁPIDO O TE ACABARÁ...
            </h2>

            <FlashSale
              title="OFERTA FLASH"
              endDate={endDate}
              products={flashSaleProducts}
            />
          </section>

          {/* Featured Products Section */}
          <section>
            <FeaturedProducts
              title="PRODUCTOS RECOMENDADOS"
              categories={featuredCategories}
              viewAllLink="/ofertas"
            />
          </section>

          {/* Additional Products */}
          <section>
            <h2 className="text-center font-bold text-hsn-text-primary text-xl mb-6">
              ¡VUELVEN A STOCK!
            </h2>

            <div className="bg-white p-6 rounded shadow-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {recommendedProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    id={product.id}
                    name={product.name}
                    brand={product.brand}
                    image={product.image}
                    description={product.description}
                    price={product.price}
                    oldPrice={product.oldPrice}
                    discount={product.discount}
                    rating={product.rating}
                    reviewCount={product.reviewCount}
                    inStock={product.inStock}
                    badge="NOVEDAD"
                    slug={product.slug}
                  />
                ))}
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
