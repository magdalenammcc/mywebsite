"use client";

import React, { useState, useEffect } from 'react';
import ProductCard from '@/components/products/ProductCard';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

// Mock data for products
const productsData = [
  {
    id: "prod1",
    name: "EVOWHEY PROTEIN",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/584605902.webp",
    description: "Proteína whey con sabor de HSN. Whey protein concentrate (concentrado de proteína de suero de leche) 80%.",
    price: 10.62,
    oldPrice: 17.90,
    discount: 41,
    rating: 4.8,
    reviewCount: 20631,
    inStock: true,
    slug: "sport-series/evowhey-protein",
    category: "proteinas",
    tags: ["sin gluten", "sin lactosa"]
  },
  {
    id: "prod2",
    name: "EVOLATE 2.0 (WHEY ISOLATE CFM)",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/1827681026.webp",
    description: "Aislado de proteína de suero de leche (WPI / Whey Iso), con sabor, de HSN.",
    price: 17.49,
    oldPrice: 26.90,
    discount: 35,
    rating: 4.7,
    reviewCount: 6755,
    inStock: false,
    slug: "sport-series/evolate-2-0-whey-isolate-cfm",
    category: "proteinas",
    tags: ["sin lactosa"]
  },
  {
    id: "prod3",
    name: "EVOCASEIN 2.0 (CASEÍNA MICELAR + DIGEZYME)",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/4055366910.webp",
    description: "100% Caseína Micelar. De vacas alimentadas con pasto. Textura cremosa. Con Digezyme. Apto para vegetarianos.",
    price: 11.54,
    oldPrice: 19.90,
    discount: 42,
    rating: 4.6,
    reviewCount: 2185,
    inStock: true,
    slug: "sport-series/evocasein-2-0-caseina-micelar-digezyme",
    category: "proteinas",
    tags: ["vegetariano"]
  },
  {
    id: "prod4",
    name: "EVONATIVE CASEIN (Lacprodan Micelpure)",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/3264842839.webp",
    description: "Aislado de caseína micelar. Lacprodan MicelPure de Arla. Primera caseína nativa del mundo con un 87% de micelas en su materia prima.",
    price: 13.28,
    oldPrice: 22.90,
    discount: 42,
    rating: 4.5,
    reviewCount: 247,
    inStock: true,
    slug: "sport-series/evonative-casein-lacprodan-micelpure",
    category: "proteinas",
    tags: ["sin soja"]
  },
  {
    id: "prod5",
    name: "EVOCLEAR HYDRO VEGAN",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/4287505174.webp",
    description: "Proteína Clear Hydro Vegan. Hidrolizado de proteína de guisante. Alta acuosidad, textura ultra-ligera.",
    price: 21.14,
    oldPrice: 39.90,
    discount: 47,
    rating: 4.3,
    reviewCount: 92,
    inStock: true,
    slug: "sport-series/evoclear-hydro-vegan",
    category: "proteinas",
    tags: ["vegano", "sin gluten"]
  },
  {
    id: "prod6",
    name: "PROTEÍNA DE SOJA AISLADA 2.0",
    brand: "Essential Series",
    image: "https://ext.same-assets.com/4253827287/343202109.webp",
    description: "Proteína vegetal aislada 100% a base de soja, máxima calidad nutricional con un sabor y textura irresistibles.",
    price: 7.48,
    oldPrice: 12.90,
    discount: 42,
    rating: 4.6,
    reviewCount: 3226,
    inStock: true,
    slug: "essential-series/proteina-de-soja-aislada-2-0",
    category: "proteinas",
    tags: ["vegano", "sin lactosa"]
  },
  {
    id: "prod8",
    name: "EVODIET 2.0",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/473826726.jpeg",
    description: "Proteina de leche y soja. Con L-carnitina L-tartrato. Con Capsimax y Tolerase.",
    price: 10.96,
    oldPrice: 18.90,
    discount: 42,
    rating: 4.3,
    reviewCount: 280,
    inStock: true,
    slug: "sport-series/evodiet-2-0",
    category: "quemadores",
    tags: ["vegetariano"]
  },
  {
    id: "prod9",
    name: "EVOBCAA 2.0 + ENERGY (BCAA + CAFEÍNA)",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/3597595621.jpeg",
    description: "BCAA 2:1:1 con Cafeína, Betaína, Electrolitos y Vitaminas.",
    price: 12.71,
    oldPrice: 21.90,
    discount: 42,
    rating: 4.7,
    reviewCount: 619,
    inStock: true,
    slug: "sport-series/evobcaa-2-0-energy-bcaa-cafeina",
    category: "aminoacidos",
    tags: ["con cafeina"]
  },
  {
    id: "prod10",
    name: "CARNITINA LS 3.0 (100% L-CARNITINA L-TARTRATO)",
    brand: "Raw Series",
    image: "https://ext.same-assets.com/4253827287/1442349358.jpeg",
    description: "L-Carnitina L-Tartrato 100% Pura. Suplemento vegano.",
    price: 7.96,
    oldPrice: 19.90,
    discount: 60,
    rating: 4.6,
    reviewCount: 323,
    inStock: true,
    slug: "raw-series/carnitina-ls-3-0-100-l-carnitina-l-tartrato",
    category: "quemadores",
    tags: ["vegano", "100% puro"]
  },
  {
    id: "rec1",
    name: "CREATINA MONOHIDRATO DE CREAPURE®",
    brand: "Sport Series",
    image: "https://ext.same-assets.com/4253827287/2599664538.jpeg",
    description: "100% Creapure® (creatina monohidrato de AlzChem) - La creatina de referencia mundial.",
    price: 14.45,
    oldPrice: 24.90,
    discount: 42,
    rating: 4.8,
    reviewCount: 11247,
    inStock: true,
    slug: "sport-series/creatina-monohidrato-creapure",
    category: "creatina",
    tags: ["sin gluten", "sin lactosa", "100% puro"]
  },
  {
    id: "rec3",
    name: "ASHWAGANDHA 500mg (WITHANIA SOMNIFERA)",
    brand: "Raw Series",
    image: "https://ext.same-assets.com/4253827287/2979023910.jpeg",
    description: "Extracto estandarizado KSM-66. Raíz de Withania somnifera. Sin excipientes.",
    price: 7.96,
    oldPrice: 19.90,
    discount: 60,
    rating: 4.7,
    reviewCount: 738,
    inStock: true,
    slug: "raw-series/ashwagandha-500mg-withania-somnifera",
    category: "anabolicos",
    tags: ["vegano", "sin gluten"]
  },
  {
    id: "rec4",
    name: "MAGNESIO MALATO",
    brand: "Raw Series",
    image: "https://ext.same-assets.com/4253827287/1183059626.jpeg",
    description: "Bis-glicinato y malato de magnesio, alta biodisponibilidad. Formato en polvo.",
    price: 5.96,
    oldPrice: 14.90,
    discount: 60,
    rating: 4.6,
    reviewCount: 876,
    inStock: true,
    slug: "raw-series/magnesio-malato",
    category: "minerales",
    tags: ["vegano", "sin gluten", "sin lactosa"]
  },
];

// Extract unique categories, brands, and tags
const categories = [...new Set(productsData.map(product => product.category))];
const brands = [...new Set(productsData.map(product => product.brand))];
const allTags = [...new Set(productsData.flatMap(product => product.tags))];

export default function ProductsPage() {
  // States for filters
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('relevance');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [filteredProducts, setFilteredProducts] = useState(productsData);

  // Handle brand selection
  const handleBrandChange = (brand: string) => {
    setSelectedBrands(prev => {
      if (prev.includes(brand)) {
        return prev.filter(b => b !== brand);
      }
      return [...prev, brand];
    });
  };

  // Handle tag selection
  const handleTagChange = (tag: string) => {
    setSelectedTags(prev => {
      if (prev.includes(tag)) {
        return prev.filter(t => t !== tag);
      }
      return [...prev, tag];
    });
  };

  // Handle price range selection
  const handlePriceRangeChange = (value: string) => {
    setPriceRange(value);
  };

  // Handle sorting change
  const handleSortChange = (value: string) => {
    setSortBy(value);
  };

  // Apply filters and sorting
  useEffect(() => {
    let result = [...productsData];

    // Filter by category
    if (selectedCategory) {
      result = result.filter(product => product.category === selectedCategory);
    }

    // Filter by brands
    if (selectedBrands.length > 0) {
      result = result.filter(product => selectedBrands.includes(product.brand));
    }

    // Filter by tags
    if (selectedTags.length > 0) {
      result = result.filter(product =>
        product.tags.some(tag => selectedTags.includes(tag))
      );
    }

    // Filter by price range
    if (priceRange !== 'all') {
      switch(priceRange) {
        case 'under10':
          result = result.filter(product => product.price < 10);
          break;
        case '10to20':
          result = result.filter(product => product.price >= 10 && product.price <= 20);
          break;
        case 'over20':
          result = result.filter(product => product.price > 20);
          break;
      }
    }

    // Filter by stock
    if (inStockOnly) {
      result = result.filter(product => product.inStock);
    }

    // Apply sorting
    switch(sortBy) {
      case 'price_asc':
        result = result.sort((a, b) => a.price - b.price);
        break;
      case 'price_desc':
        result = result.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result = result.sort((a, b) => b.rating - a.rating);
        break;
      case 'discount':
        result = result.sort((a, b) => b.discount - a.discount);
        break;
      case 'newest':
        // For demo purposes, just reverse the array
        result = result.reverse();
        break;
      // Default is 'relevance', no sorting needed
    }

    setFilteredProducts(result);
  }, [selectedCategory, selectedBrands, selectedTags, priceRange, sortBy, inStockOnly]);

  return (
    <div className="hsn-container py-8">
      <h1 className="text-2xl font-bold text-hsn-text-primary mb-6">Productos</h1>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Filters sidebar */}
        <div className="w-full md:w-64 shrink-0">
          <div className="bg-white p-4 rounded shadow-sm">
            <h2 className="font-bold text-lg mb-4">Filtros</h2>

            {/* Categories */}
            <Accordion type="single" collapsible className="mb-4">
              <AccordionItem value="categories">
                <AccordionTrigger className="text-hsn-text-primary font-semibold">
                  Categorías
                </AccordionTrigger>
                <AccordionContent>
                  <RadioGroup
                    value={selectedCategory || ''}
                    onValueChange={(value) => setSelectedCategory(value === '' ? null : value)}
                  >
                    <div className="mb-2">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="" id="all-categories" />
                        <Label htmlFor="all-categories">Todas las categorías</Label>
                      </div>
                    </div>
                    {categories.map((category) => (
                      <div key={category} className="mb-2">
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value={category} id={`category-${category}`} />
                          <Label htmlFor={`category-${category}`} className="capitalize">
                            {category}
                          </Label>
                        </div>
                      </div>
                    ))}
                  </RadioGroup>
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            {/* Brands */}
            <Accordion type="single" collapsible className="mb-4">
              <AccordionItem value="brands">
                <AccordionTrigger className="text-hsn-text-primary font-semibold">
                  Marcas
                </AccordionTrigger>
                <AccordionContent>
                  {brands.map((brand) => (
                    <div key={brand} className="mb-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id={`brand-${brand}`}
                          checked={selectedBrands.includes(brand)}
                          onCheckedChange={() => handleBrandChange(brand)}
                        />
                        <Label htmlFor={`brand-${brand}`}>{brand}</Label>
                      </div>
                    </div>
                  ))}
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            {/* Price range */}
            <Accordion type="single" collapsible className="mb-4">
              <AccordionItem value="price">
                <AccordionTrigger className="text-hsn-text-primary font-semibold">
                  Rango de precio
                </AccordionTrigger>
                <AccordionContent>
                  <RadioGroup
                    value={priceRange}
                    onValueChange={handlePriceRangeChange}
                  >
                    <div className="mb-2">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="all" id="price-all" />
                        <Label htmlFor="price-all">Todos los precios</Label>
                      </div>
                    </div>
                    <div className="mb-2">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="under10" id="price-under10" />
                        <Label htmlFor="price-under10">Menos de 10€</Label>
                      </div>
                    </div>
                    <div className="mb-2">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="10to20" id="price-10to20" />
                        <Label htmlFor="price-10to20">10€ - 20€</Label>
                      </div>
                    </div>
                    <div className="mb-2">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="over20" id="price-over20" />
                        <Label htmlFor="price-over20">Más de 20€</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            {/* Tags/Specialties */}
            <Accordion type="single" collapsible className="mb-4">
              <AccordionItem value="tags">
                <AccordionTrigger className="text-hsn-text-primary font-semibold">
                  Especialidades
                </AccordionTrigger>
                <AccordionContent>
                  {allTags.map((tag) => (
                    <div key={tag} className="mb-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id={`tag-${tag}`}
                          checked={selectedTags.includes(tag)}
                          onCheckedChange={() => handleTagChange(tag)}
                        />
                        <Label htmlFor={`tag-${tag}`} className="capitalize">{tag}</Label>
                      </div>
                    </div>
                  ))}
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            {/* In stock only */}
            <div className="mb-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="in-stock"
                  checked={inStockOnly}
                  onCheckedChange={(checked) => setInStockOnly(checked as boolean)}
                />
                <Label htmlFor="in-stock">Solo productos en stock</Label>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                setSelectedCategory(null);
                setSelectedBrands([]);
                setSelectedTags([]);
                setPriceRange('all');
                setInStockOnly(false);
                setSortBy('relevance');
              }}
            >
              Limpiar filtros
            </Button>
          </div>
        </div>

        {/* Products grid */}
        <div className="flex-1">
          {/* Sort and results count */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 bg-white p-4 rounded shadow-sm">
            <p className="text-hsn-text-secondary mb-2 sm:mb-0">
              Mostrando {filteredProducts.length} productos
            </p>
            <div className="flex items-center">
              <span className="mr-2 text-sm">Ordenar por:</span>
              <Select
                value={sortBy}
                onValueChange={handleSortChange}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Relevancia" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Relevancia</SelectItem>
                  <SelectItem value="price_asc">Precio (menor a mayor)</SelectItem>
                  <SelectItem value="price_desc">Precio (mayor a menor)</SelectItem>
                  <SelectItem value="rating">Mejor valorados</SelectItem>
                  <SelectItem value="discount">Mayor descuento</SelectItem>
                  <SelectItem value="newest">Novedades</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Products grid */}
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  id={product.id}
                  name={product.name}
                  brand={product.brand}
                  image={product.image}
                  description={product.description}
                  price={product.price}
                  oldPrice={product.oldPrice}
                  discount={product.discount}
                  rating={product.rating}
                  reviewCount={product.reviewCount}
                  inStock={product.inStock}
                  slug={product.slug}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white p-8 rounded shadow-sm text-center">
              <h3 className="text-lg font-semibold mb-2">No se encontraron productos</h3>
              <p className="text-hsn-text-secondary mb-4">
                No hay productos que coincidan con los filtros seleccionados. Prueba con otros filtros.
              </p>
              <Button
                onClick={() => {
                  setSelectedCategory(null);
                  setSelectedBrands([]);
                  setSelectedTags([]);
                  setPriceRange('all');
                  setInStockOnly(false);
                }}
              >
                Limpiar filtros
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
