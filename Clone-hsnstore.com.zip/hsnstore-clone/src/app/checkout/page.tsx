"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import Link from 'next/link';

// Mock cart items
const cartItems = [
  {
    id: 'item1',
    name: 'EVOWHEY PROTEIN',
    brand: 'Sport Series',
    image: 'https://ext.same-assets.com/4253827287/584605902.webp',
    price: 10.62,
    oldPrice: 17.90,
    discount: 41,
    size: '1kg',
    flavor: 'Chocolate',
    quantity: 2
  },
  {
    id: 'item2',
    name: 'CREATINA MONOHIDRATO DE CREAPURE®',
    brand: 'Sport Series',
    image: 'https://ext.same-assets.com/4253827287/2599664538.jpeg',
    price: 14.45,
    oldPrice: 24.90,
    discount: 42,
    size: '500g',
    quantity: 1
  }
];

export default function CheckoutPage() {
  const [cart, setCart] = useState(cartItems);
  const [couponCode, setCouponCode] = useState('');
  const [showCouponInput, setShowCouponInput] = useState(false);
  const [step, setStep] = useState(1); // 1 = cart, 2 = shipping, 3 = payment, 4 = confirmation

  // Calculate totals
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const shippingCost = subtotal > 29.99 ? 0 : 4.95;
  const discount = cart.reduce((sum, item) => sum + ((item.oldPrice - item.price) * item.quantity), 0);
  const total = subtotal + shippingCost;

  // Update quantity
  const updateQuantity = (id: string, quantity: number) => {
    if (quantity < 1) return;
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  // Remove item
  const removeItem = (id: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== id));
  };

  // Render cart items
  const renderCartItems = () => (
    <div className="space-y-4">
      {cart.length > 0 ? (
        cart.map(item => (
          <div key={item.id} className="flex flex-col sm:flex-row border border-hsn-border rounded-sm p-4">
            {/* Product Image */}
            <div className="w-full sm:w-24 h-24 flex-shrink-0 mb-4 sm:mb-0">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-contain"
              />
            </div>

            {/* Product Details */}
            <div className="flex-grow sm:ml-4">
              <div className="flex flex-col sm:flex-row justify-between">
                <div>
                  <p className="text-xs text-hsn-text-secondary">{item.brand}</p>
                  <h3 className="font-semibold">{item.name}</h3>
                  {item.flavor && (
                    <p className="text-sm text-hsn-text-secondary mb-1">Sabor: {item.flavor}</p>
                  )}
                  {item.size && (
                    <p className="text-sm text-hsn-text-secondary mb-1">Tamaño: {item.size}</p>
                  )}
                </div>

                <div className="mt-2 sm:mt-0 flex flex-col sm:items-end">
                  <div className="flex items-baseline">
                    <span className="hsn-price font-semibold">
                      {item.price.toFixed(2).replace('.', ',')}€
                    </span>
                    {item.oldPrice && (
                      <>
                        <span className="hsn-old-price text-sm ml-2">
                          {item.oldPrice.toFixed(2).replace('.', ',')}€
                        </span>
                        {item.discount && (
                          <span className="hsn-discount text-xs ml-2">
                            -{item.discount}%
                          </span>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row justify-between mt-4 items-start sm:items-center">
                {/* Quantity */}
                <div className="flex items-center mb-3 sm:mb-0">
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    className="w-8 h-8 border border-hsn-border rounded-l-sm flex items-center justify-center"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) => updateQuantity(item.id, Number.parseInt(e.target.value) || 1)}
                    className="w-12 h-8 border-t border-b border-hsn-border text-center"
                  />
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    className="w-8 h-8 border border-hsn-border rounded-r-sm flex items-center justify-center"
                  >
                    +
                  </button>
                </div>

                {/* Subtotal & Remove */}
                <div className="flex flex-col sm:items-end w-full sm:w-auto">
                  <span className="font-bold text-hsn-text-primary mb-2">
                    {(item.price * item.quantity).toFixed(2).replace('.', ',')}€
                  </span>
                  <button
                    onClick={() => removeItem(item.id)}
                    className="text-sm text-hsn-primary hover:underline"
                  >
                    Eliminar
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))
      ) : (
        <div className="text-center py-8">
          <h3 className="text-lg font-semibold mb-2">Tu cesta está vacía</h3>
          <p className="text-hsn-text-secondary mb-4">Añade algunos productos para continuar con la compra.</p>
          <Button asChild>
            <Link href="/productos">Ir a la tienda</Link>
          </Button>
        </div>
      )}
    </div>
  );

  const renderOrderSummary = () => (
    <div className="bg-white p-6 border border-hsn-border rounded-sm">
      <h2 className="text-lg font-bold text-hsn-text-primary mb-4">Resumen del pedido</h2>

      <div className="space-y-2 mb-4">
        <div className="flex justify-between">
          <span>Subtotal ({cart.reduce((sum, item) => sum + item.quantity, 0)} productos)</span>
          <span>{subtotal.toFixed(2).replace('.', ',')}€</span>
        </div>

        {discount > 0 && (
          <div className="flex justify-between text-hsn-secondary">
            <span>Descuento</span>
            <span>-{discount.toFixed(2).replace('.', ',')}€</span>
          </div>
        )}

        <div className="flex justify-between">
          <span>Gastos de envío</span>
          {shippingCost > 0 ? (
            <span>{shippingCost.toFixed(2).replace('.', ',')}€</span>
          ) : (
            <span className="text-hsn-secondary">GRATIS</span>
          )}
        </div>

        {shippingCost > 0 && (
          <div className="text-xs text-hsn-text-secondary">
            <p>Envío gratuito en pedidos superiores a 29,99€</p>
            <p>Te faltan {(29.99 - subtotal).toFixed(2).replace('.', ',')}€ para el envío gratuito</p>
          </div>
        )}
      </div>

      <div className="border-t border-hsn-border pt-4 mb-6">
        <div className="flex justify-between font-bold text-lg">
          <span>Total</span>
          <span>{total.toFixed(2).replace('.', ',')}€</span>
        </div>
        <div className="text-xs text-hsn-text-secondary mt-1">
          (IVA incluido)
        </div>
      </div>

      {/* Coupon */}
      {!showCouponInput ? (
        <button
          onClick={() => setShowCouponInput(true)}
          className="text-sm text-hsn-primary hover:underline mb-4 inline-block"
        >
          ¿Tienes un cupón de descuento?
        </button>
      ) : (
        <div className="flex mb-4">
          <Input
            type="text"
            placeholder="Código de cupón"
            value={couponCode}
            onChange={(e) => setCouponCode(e.target.value)}
            className="rounded-r-none"
          />
          <Button
            className="bg-hsn-primary hover:bg-hsn-primary/90 rounded-l-none"
          >
            Aplicar
          </Button>
        </div>
      )}

      {/* Checkout Button */}
      {cart.length > 0 && step === 1 && (
        <Button
          className="hsn-button-primary w-full"
          onClick={() => setStep(2)}
        >
          Continuar con el pago
        </Button>
      )}
    </div>
  );

  const renderShippingForm = () => (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-hsn-text-primary">Dirección de envío</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="firstName">Nombre*</Label>
          <Input id="firstName" placeholder="Nombre" required className="mt-1" />
        </div>
        <div>
          <Label htmlFor="lastName">Apellidos*</Label>
          <Input id="lastName" placeholder="Apellidos" required className="mt-1" />
        </div>
      </div>

      <div>
        <Label htmlFor="address">Dirección*</Label>
        <Input id="address" placeholder="Calle y número" required className="mt-1" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="postalCode">Código postal*</Label>
          <Input id="postalCode" placeholder="Código postal" required className="mt-1" />
        </div>
        <div className="md:col-span-2">
          <Label htmlFor="city">Ciudad*</Label>
          <Input id="city" placeholder="Ciudad" required className="mt-1" />
        </div>
      </div>

      <div>
        <Label htmlFor="country">País*</Label>
        <select
          id="country"
          className="w-full h-10 px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 mt-1"
          defaultValue="ES"
        >
          <option value="ES">España</option>
          <option value="PT">Portugal</option>
          <option value="FR">Francia</option>
          <option value="IT">Italia</option>
        </select>
      </div>

      <div>
        <Label htmlFor="phone">Teléfono*</Label>
        <Input id="phone" placeholder="Teléfono" required className="mt-1" />
      </div>

      <div>
        <Label htmlFor="email">Email*</Label>
        <Input id="email" type="email" placeholder="Email" required className="mt-1" />
      </div>

      <div className="pt-4 border-t border-hsn-border">
        <div className="flex items-center space-x-2 mb-4">
          <Checkbox id="createAccount" />
          <Label htmlFor="createAccount">Crear una cuenta para futuras compras</Label>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox id="newsletter" />
          <Label htmlFor="newsletter">Suscribirme a la newsletter</Label>
        </div>
      </div>

      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={() => setStep(1)}
        >
          Volver al carrito
        </Button>
        <Button
          className="hsn-button-primary"
          onClick={() => setStep(3)}
        >
          Continuar al pago
        </Button>
      </div>
    </div>
  );

  const renderPaymentForm = () => (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-hsn-text-primary">Método de pago</h2>

      <RadioGroup defaultValue="card">
        <div className="border border-hsn-border rounded-sm p-4 mb-4">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="card" id="payment-card" />
            <Label htmlFor="payment-card" className="font-semibold">Tarjeta de crédito / débito</Label>
          </div>
          <div className="mt-4 pl-6">
            <div className="mb-4">
              <Label htmlFor="cardNumber">Número de tarjeta*</Label>
              <Input id="cardNumber" placeholder="1234 5678 9012 3456" className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="expiryDate">Fecha de caducidad*</Label>
                <Input id="expiryDate" placeholder="MM/AA" className="mt-1" />
              </div>
              <div>
                <Label htmlFor="cvv">CVV*</Label>
                <Input id="cvv" placeholder="123" className="mt-1" />
              </div>
            </div>
          </div>
        </div>

        <div className="border border-hsn-border rounded-sm p-4 mb-4">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="paypal" id="payment-paypal" />
            <Label htmlFor="payment-paypal" className="font-semibold">PayPal</Label>
          </div>
          <p className="text-sm text-hsn-text-secondary ml-6 mt-2">
            Serás redirigido a PayPal para completar el pago.
          </p>
        </div>

        <div className="border border-hsn-border rounded-sm p-4 mb-4">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="transfer" id="payment-transfer" />
            <Label htmlFor="payment-transfer" className="font-semibold">Transferencia bancaria</Label>
          </div>
          <p className="text-sm text-hsn-text-secondary ml-6 mt-2">
            Te enviaremos las instrucciones para realizar la transferencia por email.
          </p>
        </div>
      </RadioGroup>

      <div className="pt-4 border-t border-hsn-border">
        <div className="flex items-start space-x-2 mb-4">
          <Checkbox id="terms" className="mt-1" />
          <Label htmlFor="terms" className="text-sm">
            He leído y acepto los <Link href="/terminos" className="text-hsn-primary hover:underline">Términos y Condiciones</Link> y la <Link href="/privacidad" className="text-hsn-primary hover:underline">Política de Privacidad</Link>
          </Label>
        </div>
      </div>

      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={() => setStep(2)}
        >
          Volver a envío
        </Button>
        <Button
          className="hsn-button-primary"
          onClick={() => setStep(4)}
        >
          Completar pedido
        </Button>
      </div>
    </div>
  );

  const renderConfirmation = () => (
    <div className="bg-white p-8 border border-hsn-border rounded-sm text-center">
      <div className="w-16 h-16 bg-hsn-secondary rounded-full flex items-center justify-center mx-auto mb-4">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="white"
          className="w-10 h-10"
        >
          <path
            fillRule="evenodd"
            d="M19.916 4.626a.75.75 0 01.208 1.04l-9 13.5a.75.75 0 01-1.154.114l-6-6a.75.75 0 011.06-1.06l5.353 5.353 8.493-12.739a.75.75 0 011.04-.208z"
            clipRule="evenodd"
          />
        </svg>
      </div>

      <h2 className="text-2xl font-bold text-hsn-text-primary mb-4">¡Pedido confirmado!</h2>
      <p className="text-hsn-text-secondary mb-6">
        Gracias por tu compra. Hemos enviado un email de confirmación a tu correo con los detalles del pedido.
      </p>

      <div className="mb-6 text-left border border-hsn-border rounded-sm p-4">
        <h3 className="font-semibold mb-2">Número de pedido: #HSN12345</h3>
        <p className="text-sm text-hsn-text-secondary">
          Fecha: {new Date().toLocaleDateString()}
        </p>
        <p className="text-sm text-hsn-text-secondary">
          Total: {total.toFixed(2).replace('.', ',')}€
        </p>
      </div>

      <Button asChild>
        <Link href="/">Volver a la tienda</Link>
      </Button>
    </div>
  );

  return (
    <div className="hsn-container py-8">
      {/* Page Title */}
      <h1 className="text-2xl font-bold text-hsn-text-primary mb-6">
        {step === 1 ? 'Carrito de compra' :
         step === 2 ? 'Información de envío' :
         step === 3 ? 'Método de pago' : 'Confirmación'}
      </h1>

      {/* Checkout Steps */}
      <div className="flex justify-between mb-8 border-b border-hsn-border pb-4">
        <div className={`flex flex-col items-center ${step >= 1 ? 'text-hsn-primary' : 'text-hsn-text-secondary'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${step >= 1 ? 'bg-hsn-primary text-white' : 'bg-gray-200'}`}>
            1
          </div>
          <span className="text-xs">Carrito</span>
        </div>
        <div className="border-t border-hsn-border w-full mt-4 mx-2" />
        <div className={`flex flex-col items-center ${step >= 2 ? 'text-hsn-primary' : 'text-hsn-text-secondary'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${step >= 2 ? 'bg-hsn-primary text-white' : 'bg-gray-200'}`}>
            2
          </div>
          <span className="text-xs">Envío</span>
        </div>
        <div className="border-t border-hsn-border w-full mt-4 mx-2" />
        <div className={`flex flex-col items-center ${step >= 3 ? 'text-hsn-primary' : 'text-hsn-text-secondary'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${step >= 3 ? 'bg-hsn-primary text-white' : 'bg-gray-200'}`}>
            3
          </div>
          <span className="text-xs">Pago</span>
        </div>
        <div className="border-t border-hsn-border w-full mt-4 mx-2" />
        <div className={`flex flex-col items-center ${step >= 4 ? 'text-hsn-primary' : 'text-hsn-text-secondary'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${step >= 4 ? 'bg-hsn-primary text-white' : 'bg-gray-200'}`}>
            4
          </div>
          <span className="text-xs">Confirmación</span>
        </div>
      </div>

      {/* Checkout Content */}
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Left Column - Cart/Form */}
        <div className="lg:w-2/3">
          {step === 1 && renderCartItems()}
          {step === 2 && renderShippingForm()}
          {step === 3 && renderPaymentForm()}
          {step === 4 && renderConfirmation()}
        </div>

        {/* Right Column - Order Summary */}
        {step < 4 && (
          <div className="lg:w-1/3">
            {renderOrderSummary()}
          </div>
        )}
      </div>
    </div>
  );
}
