"use client";

import type React from "react";
import Layout from "@/components/layout/Layout";

export default function ClientBody({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <body className="min-h-screen antialiased">
      <Layout>{children}</Layout>
    </body>
  );
}
